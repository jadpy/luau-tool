if true then
	print("Test")
end