local utils = {}

function utils.trim(str)
	return str:match("^%s*(.-)%s*$")
end

function utils.split(str, delimiter)
	local result = {}
	local pattern = string.format("([^%s]+)", delimiter)
	for match in str:gmatch(pattern) do
		table.insert(result, match)
	end
	return result
end

function utils.startsWith(str, prefix)
	return str:sub(1, #prefix) == prefix
end

function utils.endsWith(str, suffix)
	return str:sub(-#suffix) == suffix
end

function utils.isWhitespace(char)
	return char == " " or char == "\t" or char == "\n" or char == "\r"
end

function utils.isAlpha(char)
	local byte = string.byte(char)
	return (byte >= 65 and byte <= 90) or (byte >= 97 and byte <= 122) or char == "_"
end

function utils.isDigit(char)
	return char >= "0" and char <= "9"
end

function utils.isAlphaNumeric(char)
	return utils.isAlpha(char) or utils.isDigit(char)
end

return utils
