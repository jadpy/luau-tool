local ast = require("src.ast")
local utils = require("src.utils")

local compressor = {}

function compressor.compress(source)
	-- Line-based compressor: remove comments and empty lines, join statements with semicolons
	local outLines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		-- remove Lua single-line comments
		local code = line:gsub("%-%-.*$", "")
		-- trim
		code = code:match("^%s*(.-)%s*$") or ""
		if code ~= "" then
			table.insert(outLines, code)
		end
	end
	return table.concat(outLines, ";")
end

return compressor
