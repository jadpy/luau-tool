local ast = require("src.ast")
local utils = require("src.utils")

local linter = {}

function linter.check(source)
	local errors = {}
	local tokens = ast.tokenize(source)
	local stack = {}
	local line = 1

	for i, token in ipairs(tokens) do
		if token.type == ast.TokenType.KEYWORD then
			if token.value == "function" or token.value == "if" or token.value == "while" or token.value == "for" or token.value == "repeat" or token.value == "do" then
				table.insert(stack, {type = token.value, line = token.line})
			elseif token.value == "end" then
				if #stack == 0 then
					table.insert(errors, {
						type = "error",
						message = "Unexpected 'end'",
						line = token.line,
						column = token.column
					})
				else
					local last = stack[#stack]
					if last.type == "repeat" then
						table.remove(stack)
					else
						table.remove(stack)
					end
				end
			elseif token.value == "until" then
				if #stack == 0 or stack[#stack].type ~= "repeat" then
					table.insert(errors, {
						type = "error",
						message = "Unexpected 'until'",
						line = token.line,
						column = token.column
					})
				else
					table.remove(stack)
				end
			end
		end
	end

	for _, unclosed in ipairs(stack) do
		table.insert(errors, {
			type = "error",
			message = "Unclosed '" .. unclosed.type .. "' block",
			line = unclosed.line,
			column = 0
		})
	end

	return errors
end

function linter.formatErrors(errors)
	local output = ""
	for _, err in ipairs(errors) do
		output = output .. string.format("[%s:%d:%d] %s: %s\n", err.type, err.line, err.column, string.upper(err.type), err.message)
	end
	return output
end

return linter
