local compressor = require("src.compressor")
local formatter = require("src.formatter")
local linter = require("src.linter")

local main = {}

function main.processFile(filePath, operation, options)
	local file = io.open(filePath, "r")
	if not file then
		return {success = false, error = "Could not open file: " .. filePath}
	end

	local source = file:read("*a")
	file:close()

	if operation == "compress" then
		return {success = true, result = compressor.compress(source)}
	elseif operation == "format" then
		return {success = true, result = formatter.format(source, options)}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors)}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.processCode(source, operation, options)
	if operation == "compress" then
		return {success = true, result = compressor.compress(source)}
	elseif operation == "format" then
		return {success = true, result = formatter.format(source, options)}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors)}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

return main
