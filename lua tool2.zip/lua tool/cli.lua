local main = require("src.main")
local utils = require("src.utils")

local CLI = {
	version = "1.0.0",
	name = "Lua Tool"
}

function CLI.printVersion()
	print(CLI.name .. " v" .. CLI.version)
end

function CLI.printHelp()
	print("=" .. string.rep("=", 68) .. "=")
	print(CLI.name .. " - Luau Code Processor")
	print("=" .. string.rep("=", 68) .. "=")
	print()
	print("Usage: lua54 cli.lua <command> [options]")
	print()
	print("Commands:")
	print()
	print("  compress [file]")
	print("    Compress Lua code by removing unnecessary whitespace and comments")
 	print("    Output written to stdout, specified output file, or <input>.out<ext> by default")
	print()
	print("  format [file]")
	print("    Format Lua code with proper indentation")
 	print("    Output written to stdout, specified output file, or <input>.out<ext> by default")
	print()
	print("  lint [file]")
	print("    Check Lua code for syntax errors")
	print("    Reports errors to stdout")
	print()
	print("  help")
	print("    Display this help message")
	print()
	print("  version")
	print("    Display version information")
	print()
 	print("Options:")
 	print("  --output <file>, -o <file>   Write output to file (default: <input>.out<ext>)")
 	print("  --indent-size <n>             Set indent size (default: 2)")
 	print("  --indent-char <c>             Set indent character (tab or space)")
	print()
	print("Examples:")
	print("  lua54 cli.lua compress code.lua")
	print("  lua54 cli.lua format code.lua -o formatted.lua")
	print("  lua54 cli.lua lint code.lua")
	print()
	print("=" .. string.rep("=", 68) .. "=")
end

function CLI.parseArgs(args)
	local command = nil
	local inputFile = nil
	local outputFile = nil
	local indentSize = 2
	local indentChar = "\t"
    local lang = "en"

	if #args == 0 then
		return nil, "No command specified"
	end

	command = args[1]

	local i = 2
	while i <= #args do
		local arg = args[i]

		if arg == "--output" or arg == "-o" then
			i = i + 1
			if i <= #args then
				outputFile = args[i]
			else
				return nil, "Missing value for " .. arg
			end
		elseif arg == "--indent-size" then
			i = i + 1
			if i <= #args then
				indentSize = tonumber(args[i])
				if not indentSize then
					return nil, "Invalid indent size"
				end
			else
				return nil, "Missing value for --indent-size"
			end
		elseif arg == "--indent-char" then
			i = i + 1
			if i <= #args then
				indentChar = args[i] == "space" and " " or "\t"
			else
				return nil, "Missing value for --indent-char"
			end
        elseif arg == "--lang" then
            i = i + 1
            if i <= #args then
                lang = args[i]
            else
                return nil, "Missing value for --lang"
            end
		elseif arg:sub(1, 1) ~= "-" and not inputFile then
			inputFile = arg
		end

		i = i + 1
	end

    return {
		command = command,
		inputFile = inputFile,
		outputFile = outputFile,
		indentSize = indentSize,
		indentChar = indentChar,
		lang = lang
	}, nil
end

function CLI.readFile(filePath)
	local file, err = io.open(filePath, "r")
	if not file then
		return nil, "Cannot open file: " .. filePath .. " (" .. err .. ")"
	end

	local content = file:read("*a")
	file:close()
	return content, nil
end

function CLI.writeFile(filePath, content)
	local file, err = io.open(filePath, "w")
	if not file then
		return false, "Cannot write file: " .. filePath .. " (" .. err .. ")"
	end

	file:write(content)
	file:close()
	return true, nil
end

function CLI.compress(args)
	local source

	if args.inputFile then
		source, err = CLI.readFile(args.inputFile)
		if not source then
			print("Error: " .. err)
			return false
		end
	else
		source = io.read("*a")
	end

	local result = main.processCode(source, "compress")

	if not result.success then
		print("Error: " .. result.error)
		return false
	end

	if args.outputFile then
		local ok, err = CLI.writeFile(args.outputFile, result.result)
		if not ok then
			print("Error: " .. err)
			return false
		end
		print("Compressed and written to " .. args.outputFile)
	else
		if args.inputFile then
			local outPath
			if args.inputFile:match("%.[^%.]+$") then
				outPath = args.inputFile:gsub('(%.[^%.]+)$', '.out%1')
			else
				outPath = args.inputFile .. '.out.lua'
			end
			local ok, err = CLI.writeFile(outPath, result.result)
			if not ok then
				print("Error: " .. err)
				return false
			end
			if args.lang == 'ja' then
				print("圧縮して " .. outPath .. " に書き込みました")
			else
				print("Compressed and written to " .. outPath)
			end
		else
			print(result.result)
		end
	end

	return true
end

function CLI.format(args)
	local source

	if args.inputFile then
		source, err = CLI.readFile(args.inputFile)
		if not source then
			print("Error: " .. err)
			return false
		end
	else
		source = io.read("*a")
	end

	local result = main.processCode(source, "format", {
		indentSize = args.indentSize,
		indentChar = args.indentChar
	})

	if not result.success then
		print("Error: " .. result.error)
		return false
	end

	if args.outputFile then
		local ok, err = CLI.writeFile(args.outputFile, result.result)
		if not ok then
			print("Error: " .. err)
			return false
		end
		print("Formatted and written to " .. args.outputFile)
	else
		if args.inputFile then
			local outPath
			if args.inputFile:match("%.[^%.]+$") then
				outPath = args.inputFile:gsub('(%.[^%.]+)$', '.out%1')
			else
				outPath = args.inputFile .. '.out.lua'
			end
			local ok, err = CLI.writeFile(outPath, result.result)
			if not ok then
				print("Error: " .. err)
				return false
			end
			if args.lang == 'ja' then
				print("整形して " .. outPath .. " に書き込みました")
			else
				print("Formatted and written to " .. outPath)
			end
		else
			print(result.result)
		end
	end

	return true
end

function CLI.lint(args)
	local source

	if args.inputFile then
		source, err = CLI.readFile(args.inputFile)
		if not source then
			print("Error: " .. err)
			return false
		end
	else
		source = io.read("*a")
	end

	local result = main.processCode(source, "lint")

	if not result.success then
		print("Error: " .. result.error)
		return false
	end

	if #result.errors == 0 then
		print("No errors found!")
		return true
	else
		print(result.formatted)
		return false
	end
end

function CLI.main(args)
	local parsedArgs, parseErr = CLI.parseArgs(args)

	if not parsedArgs then
		print("Error: " .. parseErr)
		print()
		CLI.printHelp()
		return false
	end

	local command = parsedArgs.command

	if command == "help" then
		CLI.printHelp()
		return true
	elseif command == "version" then
		CLI.printVersion()
		return true
	elseif command == "compress" then
		return CLI.compress(parsedArgs)
	elseif command == "format" then
		return CLI.format(parsedArgs)
	elseif command == "lint" then
		return CLI.lint(parsedArgs)
	else
		print("Error: Unknown command '" .. command .. "'")
		print()
		CLI.printHelp()
		return false
	end
end

if arg and #arg > 0 then
	local success = CLI.main(arg)
	io.flush()
	os.exit(success and 0 or 1)
else
	CLI.printHelp()
	io.flush()
	os.exit(0)
end
