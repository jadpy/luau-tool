local main = require("src.main")

local tests = {}
tests.passed = 0
tests.failed = 0

local function assert_equals(actual, expected, test_name)
	if actual == expected then
		tests.passed = tests.passed + 1
		print("[PASS] " .. test_name)
	else
		tests.failed = tests.failed + 1
		print("[FAIL] " .. test_name)
		print("  Expected: " .. tostring(expected))
		print("  Actual: " .. tostring(actual))
	end
end

local function test_compress()
	local source = "local x = 10\nlocal y = 20"
	local result = main.processCode(source, "compress")
	assert_equals(result.success, true, "compress_basic")
	print("  Compressed: " .. result.result)
end

local function test_format()
	local source = "if true then\nprint('hello')\nend"
	local result = main.processCode(source, "format")
	assert_equals(result.success, true, "format_basic")
	print("  Formatted:\n" .. result.result)
end

local function test_lint()
	local source = "if true then\nprint('hello')\nend"
	local result = main.processCode(source, "lint")
	assert_equals(result.success, true, "lint_basic")
	print("  Errors: " .. (#result.errors == 0 and "None" or result.formatted))
end

local function test_lint_error()
	local source = "if true then\nprint('hello')"
	local result = main.processCode(source, "lint")
	assert_equals(result.success, true, "lint_unclosed")
	print("  Errors found: " .. #result.errors)
end

print("Running tests...\n")
test_compress()
print()
test_format()
print()
test_lint()
print()
test_lint_error()
print("\n" .. tests.passed .. " passed, " .. tests.failed .. " failed")
