local metest = function(testinglock)
    return testinglock * 2
end
print(metest(5))