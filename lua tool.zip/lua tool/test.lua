v = 10
t = 20
u = 15
if true then
    while true do
if false then