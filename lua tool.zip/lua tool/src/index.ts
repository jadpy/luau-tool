import { Lexer } from './lexer';
import { LuauParser } from './parser';
import { Formatter } from './formatter';
import { Minifier } from './minifier';
import { Linter } from './linter';

export class LuauTool {
  private lexer: Lexer;
  private parser?: LuauParser;
  private formatter: Formatter;
  private minifier: Minifier;
  private linter: Linter;

  constructor() {
    this.lexer = new Lexer();
    this.formatter = new Formatter();
    this.minifier = new Minifier();
    this.linter = new Linter();
  }

  // Format Luau code
  formatCode(code: string): { success: boolean; result?: string; error?: string } {
    try {
      const tokens = this.lexer.tokenize(code);
      this.parser = new LuauParser(tokens);
      const ast = this.parser.parse();
      const formatted = this.formatter.format(ast);
      return { success: true, result: formatted };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  // Minify Luau code
  minifyCode(code: string): { success: boolean; result?: string; error?: string } {
    try {
      const tokens = this.lexer.tokenize(code);
      this.parser = new LuauParser(tokens);
      const ast = this.parser.parse();
      const minified = this.minifier.minify(ast);
      const result = this.formatter.format(minified);
      return { success: true, result };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  // Lint Luau code
  lintCode(code: string): { success: boolean; errors?: any[]; error?: string } {
    try {
      const tokens = this.lexer.tokenize(code);
      this.parser = new LuauParser(tokens);
      const ast = this.parser.parse();
      const errors = this.linter.lint(ast);
      return { success: true, errors };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  // Get error details
  analyzeCode(code: string): { ast?: any; tokens?: any; errors?: any[]; parseError?: string } {
    try {
      const tokens = this.lexer.tokenize(code);
      this.parser = new LuauParser(tokens);
      const ast = this.parser.parse();
      const errors = this.linter.lint(ast);
      return { ast, tokens, errors };
    } catch (error) {
      return {
        parseError: error instanceof Error ? error.message : String(error)
      };
    }
  }
}
