import { Token, TokenType } from './tokenizer';
import { 
  Program, 
  Statement, 
  Expression, 
  LocalStatement,
  FunctionStatement,
  IfStatement,
  WhileStatement,
  ForStatement,
  ReturnStatement,
  BreakStatement,
  ExpressionStatement,
  AssignmentStatement,
  BinaryExpression,
  UnaryExpression,
  CallExpression,
  MemberExpression,
  Literal,
  Identifier,
  TableExpression,
  FunctionExpression
} from './ast';

export class LuauParser {
  private tokens: Token[];
  private current: number = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens.filter(t => t.type !== TokenType.NEWLINE);
  }

  parse(): Program {
    const statements: Statement[] = [];
    while (!this.isAtEnd()) {
      const stmt = this.parseStatement();
      if (stmt) statements.push(stmt);
    }
    return {
      type: 'Program',
      statements,
      line: 0,
      column: 0
    };
  }

  private parseStatement(): Statement | null {
    const token = this.peek();
    
    if (token.type === TokenType.LOCAL) {
      const nextToken = this.peekAhead(1);
      if (nextToken.type === TokenType.FUNCTION) {
        // local function ... end
        this.advance(); // consume 'local'
        return this.parseFunctionStatement();
      } else {
        return this.parseLocalStatement();
      }
    }
    if (token.type === TokenType.FUNCTION) {
      return this.parseFunctionStatement();
    }
    if (token.type === TokenType.IF) {
      return this.parseIfStatement();
    }
    if (token.type === TokenType.WHILE) {
      return this.parseWhileStatement();
    }
    if (token.type === TokenType.FOR) {
      return this.parseForStatement();
    }
    if (token.type === TokenType.RETURN) {
      return this.parseReturnStatement();
    }
    if (token.type === TokenType.BREAK) {
      this.advance();
      return { type: 'BreakStatement', line: token.line, column: token.column };
    }
    
    // Expression or assignment statement
    const expr = this.parseExpression();
    if (expr) {
      if (this.peek().type === TokenType.ASSIGN) {
        this.advance();
        const values = [this.parseExpression()!];
        return {
          type: 'AssignmentStatement',
          targets: [expr],
          values,
          line: token.line,
          column: token.column
        };
      }
      return {
        type: 'ExpressionStatement',
        expression: expr,
        line: token.line,
        column: token.column
      };
    }
    return null;
  }

  private parseLocalStatement(): LocalStatement {
    const token = this.advance(); // consume 'local'
    const names: string[] = [];
    
    names.push(this.consume(TokenType.IDENTIFIER, 'Expected identifier').value);
    
    while (this.peek().type === TokenType.COMMA) {
      this.advance();
      names.push(this.consume(TokenType.IDENTIFIER, 'Expected identifier').value);
    }

    const initializers: Expression[] = [];
    if (this.peek().type === TokenType.ASSIGN) {
      this.advance();
      initializers.push(this.parseExpression()!);
      while (this.peek().type === TokenType.COMMA) {
        this.advance();
        initializers.push(this.parseExpression()!);
      }
    }

    return {
      type: 'LocalStatement',
      names,
      initializers: initializers.length > 0 ? initializers : undefined,
      line: token.line,
      column: token.column
    };
  }

  private parseFunctionStatement(): FunctionStatement {
    const token = this.peek().type === TokenType.FUNCTION ? this.advance() : this.peek(); // consume 'function' if not already consumed
    if (token.type !== TokenType.FUNCTION) {
      this.advance(); // consume it if it's 'function' keyword
    }
    
    const name = this.consume(TokenType.IDENTIFIER, 'Expected function name').value;
    
    this.consume(TokenType.LPAREN, 'Expected (');
    const params: string[] = [];
    
    if (this.peek().type !== TokenType.RPAREN) {
      params.push(this.consume(TokenType.IDENTIFIER, 'Expected parameter').value);
      while (this.peek().type === TokenType.COMMA) {
        this.advance();
        params.push(this.consume(TokenType.IDENTIFIER, 'Expected parameter').value);
      }
    }
    
    this.consume(TokenType.RPAREN, 'Expected )');
    
    const body = this.parseBlock();
    this.consume(TokenType.END, 'Expected end');
    
    return {
      type: 'FunctionStatement',
      name,
      params,
      body,
      line: token.line,
      column: token.column
    };
  }

  private parseIfStatement(): IfStatement {
    const token = this.advance(); // consume 'if'
    const condition = this.parseExpression()!;
    this.consume(TokenType.THEN, 'Expected then');
    
    const thenBranch = this.parseBlock();
    
    const elseifBranches: { condition: Expression; body: Statement[] }[] = [];
    while (this.peek().type === TokenType.ELSEIF) {
      this.advance();
      const elifCond = this.parseExpression()!;
      this.consume(TokenType.THEN, 'Expected then');
      const elifBody = this.parseBlock();
      elseifBranches.push({ condition: elifCond, body: elifBody });
    }

    let elseBranch: Statement[] | undefined;
    if (this.peek().type === TokenType.ELSE) {
      this.advance();
      elseBranch = this.parseBlock();
    }

    this.consume(TokenType.END, 'Expected end');

    return {
      type: 'IfStatement',
      condition,
      thenBranch,
      elseifBranches: elseifBranches.length > 0 ? elseifBranches : undefined,
      elseBranch,
      line: token.line,
      column: token.column
    };
  }

  private parseWhileStatement(): WhileStatement {
    const token = this.advance(); // consume 'while'
    const condition = this.parseExpression()!;
    this.consume(TokenType.DO, 'Expected do');
    const body = this.parseBlock();
    this.consume(TokenType.END, 'Expected end');

    return {
      type: 'WhileStatement',
      condition,
      body,
      line: token.line,
      column: token.column
    };
  }

  private parseForStatement(): ForStatement {
    const token = this.advance(); // consume 'for'
    const variable = this.consume(TokenType.IDENTIFIER, 'Expected variable').value;
    this.consume(TokenType.ASSIGN, 'Expected =');
    
    const start = this.parseExpression()!;
    this.consume(TokenType.COMMA, 'Expected ,');
    const end = this.parseExpression()!;
    
    let step: Expression | undefined;
    if (this.peek().type === TokenType.COMMA) {
      this.advance();
      const stepExpr = this.parseExpression();
      step = stepExpr || undefined;
    }

    this.consume(TokenType.DO, 'Expected do');
    const body = this.parseBlock();
    this.consume(TokenType.END, 'Expected end');

    return {
      type: 'ForStatement',
      variable,
      start,
      end,
      step,
      body,
      line: token.line,
      column: token.column
    };
  }

  private parseReturnStatement(): ReturnStatement {
    const token = this.advance(); // consume 'return'
    const values: Expression[] = [];
    
    if (![TokenType.END, TokenType.ELSE, TokenType.ELSEIF].includes(this.peek().type)) {
      values.push(this.parseExpression()!);
      while (this.peek().type === TokenType.COMMA) {
        this.advance();
        values.push(this.parseExpression()!);
      }
    }

    return {
      type: 'ReturnStatement',
      values,
      line: token.line,
      column: token.column
    };
  }

  private parseBlock(): Statement[] {
    const statements: Statement[] = [];
    
    while (
      !this.isAtEnd() &&
      ![TokenType.END, TokenType.ELSE, TokenType.ELSEIF].includes(this.peek().type)
    ) {
      const stmt = this.parseStatement();
      if (stmt) statements.push(stmt);
    }

    return statements;
  }

  private parseExpression(): Expression | null {
    return this.parseOr();
  }

  private parseOr(): Expression | null {
    let expr = this.parseAnd();
    
    while (this.peek().type === TokenType.OR) {
      const token = this.advance();
      const right = this.parseAnd();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseAnd(): Expression | null {
    let expr = this.parseComparison();
    
    while (this.peek().type === TokenType.AND) {
      const token = this.advance();
      const right = this.parseComparison();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseComparison(): Expression | null {
    let expr = this.parseConcatenation();
    
    while ([TokenType.LT, TokenType.LTE, TokenType.GT, TokenType.GTE, 
            TokenType.EQ, TokenType.NEQ].includes(this.peek().type)) {
      const token = this.advance();
      const right = this.parseConcatenation();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseConcatenation(): Expression | null {
    let expr = this.parseAddition();
    
    while (this.peek().type === TokenType.CONCAT) {
      const token = this.advance();
      const right = this.parseAddition();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseAddition(): Expression | null {
    let expr = this.parseMultiplication();
    
    while ([TokenType.PLUS, TokenType.MINUS].includes(this.peek().type)) {
      const token = this.advance();
      const right = this.parseMultiplication();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseMultiplication(): Expression | null {
    let expr = this.parsePower();
    
    while ([TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.MODULO].includes(this.peek().type)) {
      const token = this.advance();
      const right = this.parsePower();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parsePower(): Expression | null {
    let expr = this.parseUnary();
    
    while (this.peek().type === TokenType.POWER) {
      const token = this.advance();
      const right = this.parseUnary();
      expr = {
        type: 'BinaryExpression',
        left: expr!,
        operator: token.value,
        right: right!,
        line: token.line,
        column: token.column
      };
    }

    return expr;
  }

  private parseUnary(): Expression | null {
    if ([TokenType.NOT, TokenType.MINUS].includes(this.peek().type)) {
      const token = this.advance();
      const expr = this.parseUnary();
      return {
        type: 'UnaryExpression',
        operator: token.value,
        argument: expr!,
        line: token.line,
        column: token.column
      };
    }

    return this.parseCall();
  }

  private parseCall(): Expression | null {
    let expr = this.parsePrimary();
    
    while (true) {
      if (this.peek().type === TokenType.LPAREN) {
        this.advance();
        const args: Expression[] = [];
        
        if (this.peek().type !== TokenType.RPAREN) {
          args.push(this.parseExpression()!);
          while (this.peek().type === TokenType.COMMA) {
            this.advance();
            args.push(this.parseExpression()!);
          }
        }
        
        this.consume(TokenType.RPAREN, 'Expected )');
        expr = {
          type: 'CallExpression',
          callee: expr!,
          arguments: args,
          line: this.peek().line,
          column: this.peek().column
        };
      } else if (this.peek().type === TokenType.DOT || this.peek().type === TokenType.LBRACKET) {
        const isComputed = this.peek().type === TokenType.LBRACKET;
        this.advance();
        
        const prop = isComputed ? this.parseExpression()! : 
                     { type: 'Identifier', name: this.consume(TokenType.IDENTIFIER, 'Expected identifier').value, line: 0, column: 0 } as Identifier;
        
        if (isComputed) {
          this.consume(TokenType.RBRACKET, 'Expected ]');
        }
        
        expr = {
          type: 'MemberExpression',
          object: expr!,
          property: prop,
          computed: isComputed,
          line: this.peek().line,
          column: this.peek().column
        };
      } else {
        break;
      }
    }

    return expr;
  }

  private parsePrimary(): Expression | null {
    const token = this.peek();

    if (token.type === TokenType.TRUE) {
      this.advance();
      return { type: 'Literal', value: true, raw: 'true', line: token.line, column: token.column };
    }

    if (token.type === TokenType.FALSE) {
      this.advance();
      return { type: 'Literal', value: false, raw: 'false', line: token.line, column: token.column };
    }

    if (token.type === TokenType.NIL) {
      this.advance();
      return { type: 'Literal', value: null, raw: 'nil', line: token.line, column: token.column };
    }

    if (token.type === TokenType.NUMBER) {
      this.advance();
      return { type: 'Literal', value: parseFloat(token.value), raw: token.value, line: token.line, column: token.column };
    }

    if (token.type === TokenType.STRING) {
      this.advance();
      return { type: 'Literal', value: token.value, raw: token.value, line: token.line, column: token.column };
    }

    if (token.type === TokenType.IDENTIFIER) {
      this.advance();
      return { type: 'Identifier', name: token.value, line: token.line, column: token.column };
    }

    if (token.type === TokenType.LPAREN) {
      this.advance();
      const expr = this.parseExpression();
      this.consume(TokenType.RPAREN, 'Expected )');
      return expr;
    }

    if (token.type === TokenType.LBRACE) {
      return this.parseTable();
    }

    if (token.type === TokenType.FUNCTION) {
      return this.parseFunctionExpression();
    }

    return null;
  }

  private parseTable(): TableExpression {
    const token = this.consume(TokenType.LBRACE, 'Expected {');
    const fields: any[] = [];

    while (this.peek().type !== TokenType.RBRACE && !this.isAtEnd()) {
      // Parse table field
      if (this.peek().type === TokenType.IDENTIFIER && this.peekAhead(1).type === TokenType.ASSIGN) {
        const key = this.consume(TokenType.IDENTIFIER, '').value;
        this.advance(); // consume =
        const value = this.parseExpression()!;
        fields.push({
          key: { type: 'Identifier', name: key, line: 0, column: 0 } as Identifier,
          value,
          type: 'TableField',
          line: 0,
          column: 0
        });
      } else if (this.peek().type === TokenType.LBRACKET) {
        this.advance();
        const key = this.parseExpression()!;
        this.consume(TokenType.RBRACKET, 'Expected ]');
        this.consume(TokenType.ASSIGN, 'Expected =');
        const value = this.parseExpression()!;
        fields.push({
          key,
          value,
          type: 'TableField',
          line: 0,
          column: 0
        });
      } else {
        const value = this.parseExpression()!;
        fields.push({
          value,
          type: 'TableField',
          line: 0,
          column: 0
        });
      }

      if (this.peek().type === TokenType.COMMA || this.peek().type === TokenType.SEMICOLON) {
        this.advance();
      } else if (this.peek().type !== TokenType.RBRACE) {
        break;
      }
    }

    this.consume(TokenType.RBRACE, 'Expected }');
    return {
      type: 'TableExpression',
      fields: fields as any,
      line: token.line,
      column: token.column
    };
  }

  private parseFunctionExpression(): FunctionExpression {
    const token = this.consume(TokenType.FUNCTION, 'Expected function');
    
    this.consume(TokenType.LPAREN, 'Expected (');
    const params: string[] = [];
    
    if (this.peek().type !== TokenType.RPAREN) {
      params.push(this.consume(TokenType.IDENTIFIER, 'Expected parameter').value);
      while (this.peek().type === TokenType.COMMA) {
        this.advance();
        params.push(this.consume(TokenType.IDENTIFIER, 'Expected parameter').value);
      }
    }
    
    this.consume(TokenType.RPAREN, 'Expected )');
    
    const body = this.parseBlock();
    this.consume(TokenType.END, 'Expected end');
    
    return {
      type: 'FunctionExpression',
      params,
      body,
      line: token.line,
      column: token.column
    };
  }

  private consume(type: TokenType, message: string): Token {
    if (this.peek().type === type) {
      return this.advance();
    }
    throw new Error(`${message} at line ${this.peek().line}`);
  }

  private peek(): Token {
    return this.tokens[this.current] || { type: TokenType.EOF, value: '', line: 0, column: 0 };
  }

  private peekAhead(n: number): Token {
    return this.tokens[this.current + n] || { type: TokenType.EOF, value: '', line: 0, column: 0 };
  }

  private advance(): Token {
    if (!this.isAtEnd()) this.current++;
    return this.tokens[this.current - 1];
  }

  private isAtEnd(): boolean {
    return this.peek().type === TokenType.EOF;
  }
}
