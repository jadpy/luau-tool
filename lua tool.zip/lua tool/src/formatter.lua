local ast = require("src.ast")

local formatter = {}

formatter.IndentSize = 2
formatter.IndentChar = "\t"

local function getIndent(level)
	if formatter.IndentChar == "\t" then
		return string.rep("\t", level)
	else
		return string.rep(" ", formatter.IndentSize * level)
	end
end
function formatter.format(source, options)
	options = options or {}
	formatter.IndentSize = options.indentSize or 2
	formatter.IndentChar = options.indentChar or "\t"

	local tokens = ast.tokenize(source)
	local result = {}
	local indentLevel = 0
	local atLineStart = true

	local function emit(s)
		table.insert(result, s)
	end

	local breakBefore = { ["end"] = true, ["else"] = true, ["elseif"] = true, ["until"] = true }
	local breakAfter = { ["then"] = true, ["do"] = true }

	for i, token in ipairs(tokens) do
		if token.type == ast.TokenType.EOF then break end

		if token.type == ast.TokenType.WHITESPACE or token.type == ast.TokenType.COMMENT then
		elseif token.type == ast.TokenType.KEYWORD then
			if breakBefore[token.value] then
				if not atLineStart then emit('\n') end
				indentLevel = math.max(0, indentLevel - 1)
				emit(getIndent(indentLevel))
				emit(token.value)
				emit('\n')
				atLineStart = true
				if token.value == 'else' or token.value == 'elseif' then
					indentLevel = indentLevel + 1
				end
			else
				if atLineStart then
					emit(getIndent(indentLevel))
					atLineStart = false
					emit(token.value)
				else
					emit(' ')
					emit(token.value)
				end
				if breakAfter[token.value] then
					emit('\n')
					atLineStart = true
					indentLevel = indentLevel + 1
				end
			end
		elseif token.type == ast.TokenType.IDENTIFIER or token.type == ast.TokenType.NUMBER or token.type == ast.TokenType.STRING then
			if atLineStart then
				emit(getIndent(indentLevel))
				atLineStart = false
				emit(token.value)
			else
				local last = result[#result] or ""
				local lastChar = last:sub(-1) or ""
				if lastChar == '(' or lastChar == '\n' then
					emit(token.value)
				else
					emit(' ')
					emit(token.value)
				end
			end
		elseif token.type == ast.TokenType.OPERATOR then
			local v = token.value
			if v == ',' then
				emit(',')
				emit(' ')
			elseif v == ';' then
				local last = result[#result]
				if last == ' ' then
					table.remove(result, #result)
				end
				emit('\n')
				atLineStart = true
			else
				emit(v)
			end
		end
	end

	local out = table.concat(result)
	out = out:gsub('\n+', '\n')
	out = out:gsub('\n+$', '')
	return out
end

return formatter