import { Program, Statement, Expression } from './ast';

export interface LintError {
  line: number;
  column: number;
  message: string;
  severity: 'error' | 'warning';
  code: string;
}

export class Linter {
  private errors: LintError[] = [];
  private usedVariables: Set<string> = new Set();
  private definedVariables: Set<string> = new Set();

  lint(ast: Program): LintError[] {
    this.errors = [];
    this.usedVariables.clear();
    this.definedVariables.clear();

    // Add global variables
    const globals = ['print', 'assert', 'type', 'tostring', 'tonumber', 'ipairs', 'pairs', 
                    'next', 'table', 'string', 'math', 'os', 'io', 'debug', 'coroutine'];
    globals.forEach(g => this.definedVariables.add(g));

    ast.statements.forEach(stmt => this.lintStatement(stmt));

    return this.errors;
  }

  private lintStatement(stmt: Statement): void {
    switch (stmt.type) {
      case 'LocalStatement':
        stmt.names.forEach(name => this.definedVariables.add(name));
        if (stmt.initializers) {
          stmt.initializers.forEach(init => this.lintExpression(init));
        }
        break;

      case 'FunctionStatement':
        this.definedVariables.add(stmt.name);
        stmt.params.forEach(p => this.definedVariables.add(p));
        stmt.body.forEach(s => this.lintStatement(s));
        break;

      case 'IfStatement':
        this.lintExpression(stmt.condition);
        stmt.thenBranch.forEach(s => this.lintStatement(s));
        stmt.elseifBranches?.forEach(branch => {
          this.lintExpression(branch.condition);
          branch.body.forEach(s => this.lintStatement(s));
        });
        stmt.elseBranch?.forEach(s => this.lintStatement(s));
        break;

      case 'WhileStatement':
        this.lintExpression(stmt.condition);
        stmt.body.forEach(s => this.lintStatement(s));
        break;

      case 'ForStatement':
        this.definedVariables.add(stmt.variable);
        this.lintExpression(stmt.start);
        this.lintExpression(stmt.end);
        if (stmt.step) this.lintExpression(stmt.step);
        stmt.body.forEach(s => this.lintStatement(s));
        break;

      case 'ReturnStatement':
        stmt.values.forEach(v => this.lintExpression(v));
        break;

      case 'ExpressionStatement':
        this.lintExpression(stmt.expression);
        break;

      case 'AssignmentStatement':
        stmt.targets.forEach(t => this.lintExpression(t));
        stmt.values.forEach(v => this.lintExpression(v));
        break;
    }
  }

  private lintExpression(expr: Expression): void {
    switch (expr.type) {
      case 'BinaryExpression':
        this.lintExpression(expr.left);
        this.lintExpression(expr.right);
        break;

      case 'UnaryExpression':
        this.lintExpression(expr.argument);
        break;

      case 'CallExpression':
        this.lintExpression(expr.callee);
        expr.arguments.forEach(arg => this.lintExpression(arg));
        break;

      case 'MemberExpression':
        this.lintExpression(expr.object);
        if (expr.computed) {
          this.lintExpression(expr.property);
        }
        break;

      case 'Identifier':
        this.usedVariables.add(expr.name);
        // Check if variable is defined
        if (!this.definedVariables.has(expr.name)) {
          this.errors.push({
            line: expr.line,
            column: expr.column,
            message: `Undefined variable: ${expr.name}`,
            severity: 'error',
            code: 'UNDEFINED_VARIABLE'
          });
        }
        break;

      case 'TableExpression':
        expr.fields.forEach(field => {
          if (field.key) {
            this.lintExpression(field.key);
          }
          this.lintExpression(field.value);
        });
        break;

      case 'Literal':
        // Literals don't need linting
        break;
    }
  }
}
