import { Program, Statement, Expression, BinaryExpression, UnaryExpression, CallExpression, MemberExpression, TableExpression, FunctionStatement, LocalStatement, IfStatement, WhileStatement, ForStatement, ReturnStatement, BreakStatement, ExpressionStatement, AssignmentStatement, Literal, Identifier } from './ast';

export class Formatter {
  private indent = 0;
  private indentSize = 2;

  format(ast: Program): string {
    return ast.statements
      .map(stmt => this.formatStatement(stmt))
      .join('\n');
  }

  private formatStatement(stmt: Statement, indent = 0): string {
    const indentStr = ' '.repeat(indent);

    switch (stmt.type) {
      case 'LocalStatement': {
        const localStmt = stmt as LocalStatement;
        let result = `${indentStr}local ${localStmt.names.join(', ')}`;
        if (localStmt.initializers && localStmt.initializers.length > 0) {
          result += ` = ${localStmt.initializers.map(v => this.formatExpression(v)).join(', ')}`;
        }
        return result;
      }

      case 'FunctionStatement': {
        const funcStmt = stmt as FunctionStatement;
        let result = `${indentStr}function ${funcStmt.name}(${funcStmt.params.join(', ')})\n`;
        result += funcStmt.body
          .map(s => this.formatStatement(s, indent + this.indentSize))
          .join('\n');
        result += `\n${indentStr}end`;
        return result;
      }

      case 'IfStatement': {
        const ifStmt = stmt as IfStatement;
        let result = `${indentStr}if ${this.formatExpression(ifStmt.condition)} then\n`;
        result += ifStmt.thenBranch
          .map(s => this.formatStatement(s, indent + this.indentSize))
          .join('\n');

        if (ifStmt.elseifBranches) {
          for (const branch of ifStmt.elseifBranches) {
            result += `\n${indentStr}elseif ${this.formatExpression(branch.condition)} then\n`;
            result += branch.body
              .map(s => this.formatStatement(s, indent + this.indentSize))
              .join('\n');
          }
        }

        if (ifStmt.elseBranch) {
          result += `\n${indentStr}else\n`;
          result += ifStmt.elseBranch
            .map(s => this.formatStatement(s, indent + this.indentSize))
            .join('\n');
        }

        result += `\n${indentStr}end`;
        return result;
      }

      case 'WhileStatement': {
        const whileStmt = stmt as WhileStatement;
        let result = `${indentStr}while ${this.formatExpression(whileStmt.condition)} do\n`;
        result += whileStmt.body
          .map(s => this.formatStatement(s, indent + this.indentSize))
          .join('\n');
        result += `\n${indentStr}end`;
        return result;
      }

      case 'ForStatement': {
        const forStmt = stmt as ForStatement;
        let result = `${indentStr}for ${forStmt.variable} = ${this.formatExpression(forStmt.start)}, ${this.formatExpression(forStmt.end)}`;
        if (forStmt.step) {
          result += `, ${this.formatExpression(forStmt.step)}`;
        }
        result += ` do\n`;
        result += forStmt.body
          .map(s => this.formatStatement(s, indent + this.indentSize))
          .join('\n');
        result += `\n${indentStr}end`;
        return result;
      }

      case 'ReturnStatement': {
        const returnStmt = stmt as ReturnStatement;
        if (returnStmt.values.length === 0) {
          return `${indentStr}return`;
        }
        return `${indentStr}return ${returnStmt.values.map(v => this.formatExpression(v)).join(', ')}`;
      }

      case 'BreakStatement':
        return `${indentStr}break`;

      case 'ExpressionStatement': {
        const exprStmt = stmt as ExpressionStatement;
        return `${indentStr}${this.formatExpression(exprStmt.expression)}`;
      }

      case 'AssignmentStatement': {
        const assignStmt = stmt as AssignmentStatement;
        return `${indentStr}${assignStmt.targets.map(t => this.formatExpression(t)).join(', ')} = ${assignStmt.values.map(v => this.formatExpression(v)).join(', ')}`;
      }

      default:
        return indentStr;
    }
  }

  private formatExpression(expr: Expression): string {
    switch (expr.type) {
      case 'BinaryExpression': {
        const binExpr = expr as BinaryExpression;
        return `${this.formatExpression(binExpr.left)} ${binExpr.operator} ${this.formatExpression(binExpr.right)}`;
      }

      case 'UnaryExpression': {
        const unExpr = expr as UnaryExpression;
        return `${unExpr.operator}${this.formatExpression(unExpr.argument)}`;
      }

      case 'CallExpression': {
        const callExpr = expr as CallExpression;
        return `${this.formatExpression(callExpr.callee)}(${callExpr.arguments.map(arg => this.formatExpression(arg)).join(', ')})`;
      }

      case 'MemberExpression': {
        const memExpr = expr as MemberExpression;
        const obj = this.formatExpression(memExpr.object);
        const prop = memExpr.computed
          ? `[${this.formatExpression(memExpr.property)}]`
          : `.${(memExpr.property as Identifier).name}`;
        return `${obj}${prop}`;
      }

      case 'TableExpression': {
        const tableExpr = expr as TableExpression;
        if (tableExpr.fields.length === 0) {
          return '{}';
        }
        const fields = tableExpr.fields
          .map(field => {
            if (field.key) {
              const keyStr = field.key.type === 'Identifier'
                ? (field.key as Identifier).name
                : `[${this.formatExpression(field.key)}]`;
              return `${keyStr} = ${this.formatExpression(field.value)}`;
            } else {
              return this.formatExpression(field.value);
            }
          })
          .join(', ');
        return `{ ${fields} }`;
      }

      case 'Literal': {
        const litExpr = expr as Literal;
        if (litExpr.value === null) {
          return 'nil';
        }
        if (typeof litExpr.value === 'string') {
          return `"${litExpr.value}"`;
        }
        return String(litExpr.value);
      }

      case 'Identifier': {
        const idExpr = expr as Identifier;
        return idExpr.name;
      }

      default:
        return '';
    }
  }
}
