local ast = require("src.ast")
local utils = require("src.utils")

local compressor = {}

function compressor.compress(source)
	local outLines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		local code = line:gsub("%-%-.*$", "")
		code = code:match("^%s*(.-)%s*$") or ""
		if code ~= "" then
			table.insert(outLines, code)
		end
	end
	local result = ""
	local braceDepth = 0
	for i, line in ipairs(outLines) do
		local openBraces = line:gsub("[^{]", ""):len()
		local closeBraces = line:gsub("[^}]", ""):len()
		result = result .. line
		braceDepth = braceDepth + openBraces - closeBraces
		if i < #outLines then
			local trimmedLine = line:match("^%s*(.-)%s*$") or ""
			if braceDepth == 0 and trimmedLine:sub(-1) ~= "," then
				result = result .. ";"
			end
		end
	end
	
	return result
end

return compressor
