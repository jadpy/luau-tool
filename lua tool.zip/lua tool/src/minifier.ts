import { Program, Statement, Expression, BinaryExpression, UnaryExpression, CallExpression, Identifier } from './ast';

export class Minifier {
  private variableMap: Map<string, string> = new Map();
  private varCounter = 0;
  private globalVariables: Set<string> = new Set(['print', 'assert', 'type', 'tostring', 'tonumber', 'ipairs', 'pairs', 'next', 'table', 'string', 'math', 'os', 'io']);

  minify(ast: Program): Program {
    this.variableMap.clear();
    this.varCounter = 0;

    // First pass: collect all local variables
    this.collectVariables(ast);

    return {
      ...ast,
      statements: ast.statements.map(stmt => this.minifyStatement(stmt))
    };
  }

  private collectVariables(ast: Program): void {
    ast.statements.forEach(stmt => this.collectFromStatement(stmt));
  }

  private collectFromStatement(stmt: Statement): void {
    switch (stmt.type) {
      case 'LocalStatement':
        stmt.names.forEach(name => {
          if (!this.variableMap.has(name)) {
            this.variableMap.set(name, this.generateMinifiedName());
          }
        });
        break;

      case 'FunctionStatement':
        // Don't minify function names that aren't local
        if ((stmt as any).isLocal !== false) {
          stmt.params.forEach(p => {
            if (!this.variableMap.has(p)) {
              this.variableMap.set(p, this.generateMinifiedName());
            }
          });
        }
        stmt.body.forEach(s => this.collectFromStatement(s));
        break;

      case 'IfStatement':
        stmt.thenBranch.forEach(s => this.collectFromStatement(s));
        stmt.elseifBranches?.forEach(b => b.body.forEach(s => this.collectFromStatement(s)));
        stmt.elseBranch?.forEach(s => this.collectFromStatement(s));
        break;

      case 'WhileStatement':
        stmt.body.forEach(s => this.collectFromStatement(s));
        break;

      case 'ForStatement':
        this.variableMap.set(stmt.variable, this.generateMinifiedName());
        stmt.body.forEach(s => this.collectFromStatement(s));
        break;
    }
  }

  private minifyStatement(stmt: Statement): Statement {
    switch (stmt.type) {
      case 'LocalStatement':
        return {
          ...stmt,
          names: stmt.names.map(name => this.variableMap.get(name) || name)
        };

      case 'FunctionStatement':
        return {
          ...stmt,
          params: stmt.params.map(p => this.variableMap.get(p) || p),
          body: stmt.body.map(s => this.minifyStatement(s))
        };

      case 'IfStatement':
        return {
          ...stmt,
          condition: this.minifyExpression(stmt.condition),
          thenBranch: stmt.thenBranch.map(s => this.minifyStatement(s)),
          elseifBranches: stmt.elseifBranches?.map(branch => ({
            condition: this.minifyExpression(branch.condition),
            body: branch.body.map(s => this.minifyStatement(s))
          })),
          elseBranch: stmt.elseBranch?.map(s => this.minifyStatement(s))
        };

      case 'WhileStatement':
        return {
          ...stmt,
          condition: this.minifyExpression(stmt.condition),
          body: stmt.body.map(s => this.minifyStatement(s))
        };

      case 'ForStatement':
        return {
          ...stmt,
          variable: this.variableMap.get(stmt.variable) || stmt.variable,
          start: this.minifyExpression(stmt.start),
          end: this.minifyExpression(stmt.end),
          step: stmt.step ? this.minifyExpression(stmt.step) : undefined,
          body: stmt.body.map(s => this.minifyStatement(s))
        };

      case 'ReturnStatement':
        return {
          ...stmt,
          values: stmt.values.map(v => this.minifyExpression(v))
        };

      case 'ExpressionStatement':
        return {
          ...stmt,
          expression: this.minifyExpression(stmt.expression)
        };

      case 'AssignmentStatement':
        return {
          ...stmt,
          targets: stmt.targets.map(t => this.minifyExpression(t)),
          values: stmt.values.map(v => this.minifyExpression(v))
        };

      default:
        return stmt;
    }
  }

  private minifyExpression(expr: Expression): Expression {
    switch (expr.type) {
      case 'BinaryExpression': {
        const binExpr = expr as BinaryExpression;
        return {
          ...binExpr,
          left: this.minifyExpression(binExpr.left),
          right: this.minifyExpression(binExpr.right)
        };
      }

      case 'UnaryExpression': {
        const unExpr = expr as UnaryExpression;
        return {
          ...unExpr,
          argument: this.minifyExpression(unExpr.argument)
        };
      }

      case 'CallExpression': {
        const callExpr = expr as CallExpression;
        return {
          ...callExpr,
          callee: this.minifyExpression(callExpr.callee),
          arguments: callExpr.arguments.map(arg => this.minifyExpression(arg))
        };
      }

      case 'Identifier': {
        const idExpr = expr as Identifier;
        const minified = this.variableMap.get(idExpr.name);
        return {
          ...idExpr,
          name: minified || idExpr.name
        };
      }

      default:
        return expr;
    }
  }

  private generateMinifiedName(): string {
    const chars = 'abcdefghijklmnopqrstuvwxyz';
    if (this.varCounter < chars.length) {
      return chars[this.varCounter++];
    }
    const base = Math.floor((this.varCounter - chars.length) / chars.length);
    const offset = (this.varCounter - chars.length) % chars.length;
    this.varCounter++;
    return chars[offset] + base;
  }
}
