#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { LuauTool } from './index';

const tool = new LuauTool();

function showHelp() {
  console.log(`
Luau Tool - Code processing tool for Luau

Usage: luau-tool <command> <input-file> [options]

Commands:
  format <file>      フォーマットされたコードを出力
  minify <file>      ミニファイされたコードを出力
  lint <file>        エラーと問題を検出
  analyze <file>     ASTとエラーの詳細を表示

Options:
  -o, --output <file>  出力ファイルを指定 (デフォルト: stdout)
  --help               このメッセージを表示

Examples:
  luau-tool format code.luau
  luau-tool minify code.luau -o output.luau
  luau-tool lint code.luau
  luau-tool analyze code.luau
`);
}

async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') {
    showHelp();
    process.exit(0);
  }

  const command = args[0];
  const inputFile = args[1];
  const outputIndex = args.indexOf('-o') !== -1 ? args.indexOf('-o') : args.indexOf('--output');
  const outputFile = outputIndex !== -1 ? args[outputIndex + 1] : null;

  if (!inputFile || !fs.existsSync(inputFile)) {
    console.error(`エラー: ファイルが見つかりません: ${inputFile}`);
    process.exit(1);
  }

  const code = fs.readFileSync(inputFile, 'utf8');

  switch (command) {
    case 'format': {
      const result = tool.formatCode(code);
      if (result.success && result.result) {
        const output = result.result;
        if (outputFile) {
          fs.writeFileSync(outputFile, output, 'utf8');
          console.log(`フォーマット完了: ${outputFile}`);
        } else {
          console.log(output);
        }
      } else {
        console.error(`エラー: ${result.error}`);
        process.exit(1);
      }
      break;
    }

    case 'minify': {
      const result = tool.minifyCode(code);
      if (result.success && result.result) {
        const output = result.result;
        if (outputFile) {
          fs.writeFileSync(outputFile, output, 'utf8');
          console.log(`ミニファイ完了: ${outputFile}`);
        } else {
          console.log(output);
        }
      } else {
        console.error(`エラー: ${result.error}`);
        process.exit(1);
      }
      break;
    }

    case 'lint': {
      const result = tool.lintCode(code);
      if (result.success) {
        if (result.errors && result.errors.length > 0) {
          console.log(`${result.errors.length} 個のエラーが見つかりました:`);
          result.errors.forEach((error) => {
            const severity = error.severity === 'error' ? '❌' : '⚠️';
            console.log(`${severity} [${error.code}] Line ${error.line}, Column ${error.column}: ${error.message}`);
          });
          process.exit(1);
        } else {
          console.log('✅ エラーは見つかりませんでした');
        }
      } else {
        console.error(`エラー: ${result.error}`);
        process.exit(1);
      }
      break;
    }

    case 'analyze': {
      const result = tool.analyzeCode(code);
      if (result.parseError) {
        console.error(`解析エラー: ${result.parseError}`);
        process.exit(1);
      }

      console.log('=== AST ===');
      console.log(JSON.stringify(result.ast, null, 2));

      if (result.errors && result.errors.length > 0) {
        console.log('\n=== エラー ===');
        result.errors.forEach((error) => {
          console.log(`[${error.code}] Line ${error.line}: ${error.message}`);
        });
      } else {
        console.log('\n=== エラー ===');
        console.log('見つかりません');
      }
      break;
    }

    default:
      console.error(`不明なコマンド: ${command}`);
      showHelp();
      process.exit(1);
  }
}

main().catch((error) => {
  console.error('予期しないエラー:', error);
  process.exit(1);
});
