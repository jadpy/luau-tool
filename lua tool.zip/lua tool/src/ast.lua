local utils = require("src.utils")

local ast = {}

ast.TokenType = {
	KEYWORD = "KEYWORD",
	IDENTIFIER = "IDENTIFIER",
	STRING = "STRING",
	NUMBER = "NUMBER",
	OPERATOR = "OPERATOR",
	PUNCTUATION = "PUNCTUATION",
	WHITESPACE = "WHITESPACE",
	COMMENT = "COMMENT",
	EOF = "EOF"
}

local KEYWORDS = {
	["and"] = true, ["break"] = true, ["do"] = true, ["else"] = true,
	["elseif"] = true, ["end"] = true, ["false"] = true, ["for"] = true,
	["function"] = true, ["if"] = true, ["in"] = true, ["local"] = true,
	["nil"] = true, ["not"] = true, ["or"] = true, ["repeat"] = true,
	["return"] = true, ["then"] = true, ["true"] = true, ["until"] = true,
	["while"] = true, ["type"] = true, ["continue"] = true, ["typeof"] = true
}

local function newToken(type, value, line, column)
	return {
		type = type,
		value = value,
		line = line,
		column = column
	}
end

function ast.tokenize(source)
	local tokens = {}
	local line = 1
	local column = 1
	local i = 1

	while i <= #source do
		local char = source:sub(i, i)
		local nextChar = source:sub(i + 1, i + 1)

		if char == "\n" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "\n", line, column))
			line = line + 1
			column = 1
			i = i + 1
		elseif char == " " or char == "\t" or char == "\r" then
			local ws = ""
			local startCol = column
			while i <= #source do
				local c = source:sub(i, i)
				if c ~= " " and c ~= "\t" and c ~= "\r" and c ~= "\n" then
					break
				end
				if c == "\n" then
					break
				end
				ws = ws .. c
				i = i + 1
				column = column + 1
			end
			table.insert(tokens, newToken(ast.TokenType.WHITESPACE, ws, line, startCol))
		elseif char == "-" and nextChar == "-" then
			local comment = ""
			local startCol = column
			while i <= #source do
				local c = source:sub(i, i)
				if c == "\n" then
					break
				end
				comment = comment .. c
				i = i + 1
				column = column + 1
			end
			table.insert(tokens, newToken(ast.TokenType.COMMENT, comment, line, startCol))
		elseif (char == '"' or char == "'") then
			local quote = char
			local str = quote
			local startCol = column
			i = i + 1
			column = column + 1
			while i <= #source do
				local c = source:sub(i, i)
				str = str .. c
				if c == quote then
					i = i + 1
					column = column + 1
					break
				elseif c == "\\" then
					str = str .. source:sub(i + 1, i + 1)
					i = i + 2
					column = column + 2
				else
					i = i + 1
					column = column + 1
				end
			end
			table.insert(tokens, newToken(ast.TokenType.STRING, str, line, startCol))
		elseif char >= "0" and char <= "9" then
			local num = ""
			local startCol = column
			while i <= #source do
				local c = source:sub(i, i)
				if (c >= "0" and c <= "9") or c == "." then
					num = num .. c
					i = i + 1
					column = column + 1
				else
					break
				end
			end
			table.insert(tokens, newToken(ast.TokenType.NUMBER, num, line, startCol))
		elseif (char >= "a" and char <= "z") or (char >= "A" and char <= "Z") or char == "_" then
			local ident = ""
			local startCol = column
			while i <= #source do
				local c = source:sub(i, i)
				if (c >= "a" and c <= "z") or (c >= "A" and c <= "Z") or (c >= "0" and c <= "9") or c == "_" then
					ident = ident .. c
					i = i + 1
					column = column + 1
				else
					break
				end
			end
			if KEYWORDS[ident] then
				table.insert(tokens, newToken(ast.TokenType.KEYWORD, ident, line, startCol))
			else
				table.insert(tokens, newToken(ast.TokenType.IDENTIFIER, ident, line, startCol))
			end
		elseif char == "=" and nextChar == "=" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "==", line, column))
			i = i + 2
			column = column + 2
		elseif char == "~" and nextChar == "=" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "~=", line, column))
			i = i + 2
			column = column + 2
		elseif char == "<" and nextChar == "=" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "<=", line, column))
			i = i + 2
			column = column + 2
		elseif char == ">" and nextChar == "=" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, ">=", line, column))
			i = i + 2
			column = column + 2
		elseif char == "." and nextChar == "." then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "..", line, column))
			i = i + 2
			column = column + 2
		elseif char == ":" and nextChar == ":" then
			table.insert(tokens, newToken(ast.TokenType.OPERATOR, "::", line, column))
			i = i + 2
			column = column + 2
		else
			local opChars = "+-*/%^<>=(){}[],.:;?#&|"
			local isOp = false
			for j = 1, #opChars do
				if opChars:sub(j, j) == char then
					isOp = true
					break
				end
			end
			if isOp then
				table.insert(tokens, newToken(ast.TokenType.OPERATOR, char, line, column))
				i = i + 1
				column = column + 1
			else
				i = i + 1
				column = column + 1
			end
		end
	end

	table.insert(tokens, newToken(ast.TokenType.EOF, "", line, column))
	return tokens
end

function ast.parse(tokens)
	local ast_tree = {
		type = "program",
		body = {}
	}
	return ast_tree
end

return ast

