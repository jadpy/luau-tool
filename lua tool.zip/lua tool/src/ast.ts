// AST Node types for Luau
export interface ASTNode {
  type: string;
  line: number;
  column: number;
}

export interface Program extends ASTNode {
  type: 'Program';
  statements: Statement[];
}

export type Statement =
  | LocalStatement
  | FunctionStatement
  | IfStatement
  | WhileStatement
  | ForStatement
  | ReturnStatement
  | BreakStatement
  | ExpressionStatement
  | AssignmentStatement;

export interface LocalStatement extends ASTNode {
  type: 'LocalStatement';
  names: string[];
  initializers?: Expression[];
}

export interface FunctionStatement extends ASTNode {
  type: 'FunctionStatement';
  name: string;
  params: string[];
  body: Statement[];
}

export interface IfStatement extends ASTNode {
  type: 'IfStatement';
  condition: Expression;
  thenBranch: Statement[];
  elseifBranches?: { condition: Expression; body: Statement[] }[];
  elseBranch?: Statement[];
}

export interface WhileStatement extends ASTNode {
  type: 'WhileStatement';
  condition: Expression;
  body: Statement[];
}

export interface ForStatement extends ASTNode {
  type: 'ForStatement';
  variable: string;
  start: Expression;
  end: Expression;
  step?: Expression;
  body: Statement[];
}

export interface ReturnStatement extends ASTNode {
  type: 'ReturnStatement';
  values: Expression[];
}

export interface BreakStatement extends ASTNode {
  type: 'BreakStatement';
}

export interface ExpressionStatement extends ASTNode {
  type: 'ExpressionStatement';
  expression: Expression;
}

export interface AssignmentStatement extends ASTNode {
  type: 'AssignmentStatement';
  targets: Expression[];
  values: Expression[];
}

export type Expression =
  | BinaryExpression
  | UnaryExpression
  | CallExpression
  | MemberExpression
  | Literal
  | Identifier
  | TableExpression
  | FunctionExpression;

export interface BinaryExpression extends ASTNode {
  type: 'BinaryExpression';
  left: Expression;
  operator: string;
  right: Expression;
}

export interface UnaryExpression extends ASTNode {
  type: 'UnaryExpression';
  operator: string;
  argument: Expression;
}

export interface CallExpression extends ASTNode {
  type: 'CallExpression';
  callee: Expression;
  arguments: Expression[];
}

export interface MemberExpression extends ASTNode {
  type: 'MemberExpression';
  object: Expression;
  property: Expression;
  computed: boolean;
}

export interface Literal extends ASTNode {
  type: 'Literal';
  value: string | number | boolean | null;
  raw: string;
}

export interface Identifier extends ASTNode {
  type: 'Identifier';
  name: string;
}

export interface TableExpression extends ASTNode {
  type: 'TableExpression';
  fields: TableField[];
}

export interface TableField extends ASTNode {
  key?: Expression;
  value: Expression;
}

export interface FunctionExpression extends ASTNode {
  type: 'FunctionExpression';
  params: string[];
  body: Statement[];
}
