import { TokenType, Token } from './tokenizer';

export class Lexer {
  private source: string = '';
  private position: number = 0;
  private line: number = 1;
  private column: number = 1;
  private tokens: Token[] = [];

  tokenize(source: string): Token[] {
    this.source = source;
    this.position = 0;
    this.line = 1;
    this.column = 1;
    this.tokens = [];

    while (this.position < this.source.length) {
      const ch = this.current();

      // Comments
      if (ch === '-' && this.peek() === '-') {
        this.skipComment();
        continue;
      }

      // Skip whitespace
      if (ch === ' ' || ch === '\t' || ch === '\r') {
        this.advance();
        continue;
      }

      // Newline
      if (ch === '\n') {
        this.addToken(TokenType.NEWLINE, '\n');
        this.advance();
        this.line++;
        this.column = 1;
        continue;
      }

      // Strings
      if (ch === '"' || ch === "'") {
        this.scanString();
        continue;
      }

      // Numbers
      if (this.isDigit(ch)) {
        this.scanNumber();
        continue;
      }

      // Identifiers and keywords
      if (this.isIdentifierStart(ch)) {
        this.scanIdentifier();
        continue;
      }

      // Operators and delimiters
      switch (ch) {
        case '(':
          this.addToken(TokenType.LPAREN, '(');
          this.advance();
          break;
        case ')':
          this.addToken(TokenType.RPAREN, ')');
          this.advance();
          break;
        case '{':
          this.addToken(TokenType.LBRACE, '{');
          this.advance();
          break;
        case '}':
          this.addToken(TokenType.RBRACE, '}');
          this.advance();
          break;
        case '[':
          this.addToken(TokenType.LBRACKET, '[');
          this.advance();
          break;
        case ']':
          this.addToken(TokenType.RBRACKET, ']');
          this.advance();
          break;
        case ',':
          this.addToken(TokenType.COMMA, ',');
          this.advance();
          break;
        case ';':
          this.addToken(TokenType.SEMICOLON, ';');
          this.advance();
          break;
        case ':':
          this.addToken(TokenType.COLON, ':');
          this.advance();
          break;
        case '.':
          if (this.peek() === '.' && this.peekAhead(2) === '.') {
            this.addToken(TokenType.CONCAT, '...');
            this.advance();
            this.advance();
            this.advance();
          } else if (this.peek() === '.') {
            this.addToken(TokenType.CONCAT, '..');
            this.advance();
            this.advance();
          } else {
            this.addToken(TokenType.DOT, '.');
            this.advance();
          }
          break;
        case '+':
          this.addToken(TokenType.PLUS, '+');
          this.advance();
          break;
        case '-':
          this.addToken(TokenType.MINUS, '-');
          this.advance();
          break;
        case '*':
          this.addToken(TokenType.MULTIPLY, '*');
          this.advance();
          break;
        case '/':
          this.addToken(TokenType.DIVIDE, '/');
          this.advance();
          break;
        case '%':
          this.addToken(TokenType.MODULO, '%');
          this.advance();
          break;
        case '^':
          this.addToken(TokenType.POWER, '^');
          this.advance();
          break;
        case '=':
          if (this.peek() === '=') {
            this.addToken(TokenType.EQ, '==');
            this.advance();
            this.advance();
          } else {
            this.addToken(TokenType.ASSIGN, '=');
            this.advance();
          }
          break;
        case '~':
          if (this.peek() === '=') {
            this.addToken(TokenType.NEQ, '~=');
            this.advance();
            this.advance();
          } else {
            this.advance();
          }
          break;
        case '<':
          if (this.peek() === '=') {
            this.addToken(TokenType.LTE, '<=');
            this.advance();
            this.advance();
          } else {
            this.addToken(TokenType.LT, '<');
            this.advance();
          }
          break;
        case '>':
          if (this.peek() === '=') {
            this.addToken(TokenType.GTE, '>=');
            this.advance();
            this.advance();
          } else {
            this.addToken(TokenType.GT, '>');
            this.advance();
          }
          break;
        default:
          this.advance();
          break;
      }
    }

    this.addToken(TokenType.EOF, '');
    return this.tokens;
  }

  private scanString(): void {
    const quote = this.current();
    const startLine = this.line;
    const startColumn = this.column;
    this.advance(); // consume opening quote

    let value = '';
    while (this.position < this.source.length && this.current() !== quote) {
      if (this.current() === '\\') {
        this.advance();
        if (this.position < this.source.length) {
          const escaped = this.current();
          switch (escaped) {
            case 'n':
              value += '\n';
              break;
            case 't':
              value += '\t';
              break;
            case 'r':
              value += '\r';
              break;
            case '\\':
              value += '\\';
              break;
            case '"':
              value += '"';
              break;
            case "'":
              value += "'";
              break;
            default:
              value += escaped;
              break;
          }
          this.advance();
        }
      } else {
        value += this.current();
        if (this.current() === '\n') {
          this.line++;
          this.column = 1;
        } else {
          this.column++;
        }
        this.advance();
      }
    }

    if (this.position < this.source.length) {
      this.advance(); // consume closing quote
    }

    this.tokens.push({
      type: TokenType.STRING,
      value,
      line: startLine,
      column: startColumn
    });
  }

  private scanNumber(): void {
    const startLine = this.line;
    const startColumn = this.column;
    let value = '';

    while (this.isDigit(this.current())) {
      value += this.current();
      this.advance();
    }

    if (this.current() === '.' && this.isDigit(this.peek())) {
      value += '.';
      this.advance();
      while (this.isDigit(this.current())) {
        value += this.current();
        this.advance();
      }
    }

    if (this.current() === 'e' || this.current() === 'E') {
      value += this.current();
      this.advance();
      if (this.current() === '+' || this.current() === '-') {
        value += this.current();
        this.advance();
      }
      while (this.isDigit(this.current())) {
        value += this.current();
        this.advance();
      }
    }

    this.tokens.push({
      type: TokenType.NUMBER,
      value,
      line: startLine,
      column: startColumn
    });
  }

  private scanIdentifier(): void {
    const startLine = this.line;
    const startColumn = this.column;
    let value = '';

    while (this.isIdentifierPart(this.current())) {
      value += this.current();
      this.advance();
    }

    const type = this.getKeywordType(value);
    this.tokens.push({
      type,
      value,
      line: startLine,
      column: startColumn
    });
  }

  private skipComment(): void {
    while (this.position < this.source.length && this.current() !== '\n') {
      this.advance();
    }
  }

  private getKeywordType(value: string): TokenType {
    const keywords: { [key: string]: TokenType } = {
      'local': TokenType.LOCAL,
      'function': TokenType.FUNCTION,
      'end': TokenType.END,
      'if': TokenType.IF,
      'then': TokenType.THEN,
      'else': TokenType.ELSE,
      'elseif': TokenType.ELSEIF,
      'for': TokenType.FOR,
      'while': TokenType.WHILE,
      'do': TokenType.DO,
      'return': TokenType.RETURN,
      'break': TokenType.BREAK,
      'continue': TokenType.CONTINUE,
      'nil': TokenType.NIL,
      'true': TokenType.TRUE,
      'false': TokenType.FALSE,
      'and': TokenType.AND,
      'or': TokenType.OR,
      'not': TokenType.NOT,
    };

    return keywords[value] || TokenType.IDENTIFIER;
  }

  private addToken(type: TokenType, value: string): void {
    this.tokens.push({
      type,
      value,
      line: this.line,
      column: this.column
    });
  }

  private current(): string {
    return this.position < this.source.length ? this.source[this.position] : '\0';
  }

  private peek(): string {
    return this.position + 1 < this.source.length ? this.source[this.position + 1] : '\0';
  }

  private peekAhead(n: number): string {
    return this.position + n < this.source.length ? this.source[this.position + n] : '\0';
  }

  private advance(): void {
    if (this.position < this.source.length) {
      this.position++;
      this.column++;
    }
  }

  private isDigit(ch: string): boolean {
    return ch >= '0' && ch <= '9';
  }

  private isIdentifierStart(ch: string): boolean {
    return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch === '_';
  }

  private isIdentifierPart(ch: string): boolean {
    return this.isIdentifierStart(ch) || this.isDigit(ch);
  }
}
