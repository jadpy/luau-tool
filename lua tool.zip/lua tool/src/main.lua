local compressor = require("src.compressor")
local formatter = require("src.formatter")
local linter = require("src.linter")
local ast = require("src.ast")

local main = {}

main.OPERATIONS = {
	compress = true,
	format = true,
	lint = true,
	fixcode = true,
	["local"] = true,
	dlocal = true,
	rename = true
}

function main.processFile(filePath, operation, options)
	local file = io.open(filePath, "r")
	if not file then
		return {success = false, error = "Could not open file: " .. filePath}
	end

	local source = file:read("*a")
	file:close()

	local stats = main.getStats(source)

	if operation == "compress" then
		local result = compressor.compress(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "format" then
		local result = formatter.format(source, options)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors), stats = stats}
	elseif operation == "fixcode" then
		local result, fixes = main.fixcode(source)
		return {success = true, result = result, fixes = fixes, dryRun = options.dryRun, stats = stats}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals, stats = stats}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "rename" then
		local result = main.rename(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.processCode(source, operation, options)
	local stats = main.getStats(source)
	
	if operation == "compress" then
		local result = compressor.compress(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "format" then
		local result = formatter.format(source, options)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors), stats = stats}
	elseif operation == "fixcode" then
		local result, fixes = main.fixcode(source)
		return {success = true, result = result, fixes = fixes, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals, stats = stats}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "rename" then
		local result = main.rename(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.getStats(source)
	local lines = 0
	for _ in source:gmatch("\n") do
		lines = lines + 1
	end
	if #source > 0 and source:sub(-1) ~= "\n" then
		lines = lines + 1
	end
	if lines == 0 and #source > 0 then
		lines = 1
	end
	
	local tokens = ast.tokenize(source)
	local tokenCount = #tokens - 1
	
	return {
		lines = lines,
		tokens = tokenCount,
		bytes = #source
	}
end

function main.fixcode(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local result = ""
	local fixes = {}
	
	for i, line in ipairs(lines) do
		local indent = line:match("^(%s*)")
		local content = line:sub(#indent + 1)
		if #content > 0 then
			local newContent = content:gsub("(%w+)%s+%(", "%1(")
			if newContent ~= content then
				table.insert(fixes, {line = i, msg = "removed space before '('"})
				content = newContent
			end
			newContent = content:gsub(",([^%s\n])", ", %1")
			if newContent ~= content then
				table.insert(fixes, {line = i, msg = "added space after comma"})
				content = newContent
			end
			newContent = content:gsub("  +", " ")
			if newContent ~= content then
				table.insert(fixes, {line = i, msg = "normalized multiple spaces"})
				content = newContent
			end
			
			result = result .. indent .. content .. "\n"
		else
			result = result .. "\n"
		end
	end
	if result:sub(-1) ~= "\n" then
		result = result .. "\n"
	end
	
	return result, fixes
end

function main.countLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local count = 0
	local locals = {}
	local depth = 0
	for _, line in ipairs(lines) do
		local code = line
		local commentStart = line:find("%-%-")
		if commentStart then
			code = line:sub(1, commentStart - 1)
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		if code:match("^%s*local%s+") and prevDepth == 0 then
			local declarators = code:match("^%s*local%s+(.*)$")
			if declarators then
				for decl in declarators:gmatch("[^,]+") do
					decl = decl:match("^%s*(.-)%s*$") or ""
					local var = decl:match("^([%w_]+)")
					if var then
						count = count + 1
						table.insert(locals, var)
					end
				end
			end
		end
	end
	
	return count, locals
end

function main.deleteLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local result = ""
	local depth = 0
	
	for _, line in ipairs(lines) do
		local commentStart = line:find("%-%-")
		local code, comment
		
		if commentStart then
			code = line:sub(1, commentStart - 1)
			comment = line:sub(commentStart)
		else
			code = line
			comment = ""
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		
		if code:match("^%s*local%s+") and code:find("=") and prevDepth == 0 then
			local newCode = code:gsub("^(%s*)local%s+", "%1", 1)
			result = result .. newCode .. comment .. "\n"
		else
			result = result .. line .. "\n"
		end
	end
	
	return result:match("^(.-)%s*$")
end

function main.rename(source)
	local tokens = ast.tokenize(source)
	local varMap = {}
	local usedChars = {}
	
	local protected = {
		["if"] = true, ["then"] = true, ["else"] = true, ["elseif"] = true, ["end"] = true,
		["for"] = true, ["while"] = true, ["repeat"] = true, ["until"] = true, ["do"] = true,
		["function"] = true, ["local"] = true, ["return"] = true, ["break"] = true,
		["and"] = true, ["or"] = true, ["not"] = true, ["nil"] = true, ["true"] = true, ["false"] = true,
		["in"] = true, ["continue"] = true,
		["print"] = true, ["type"] = true, ["typeof"] = true, ["pairs"] = true, ["ipairs"] = true,
		["next"] = true, ["tonumber"] = true, ["tostring"] = true, ["assert"] = true, ["error"] = true,
		["pcall"] = true, ["xpcall"] = true, ["load"] = true, ["loadstring"] = true, ["require"] = true,
		["module"] = true, ["os"] = true, ["io"] = true, ["math"] = true, ["string"] = true, ["table"] = true,
		["debug"] = true, ["coroutine"] = true, ["setmetatable"] = true, ["getmetatable"] = true,
		["rawget"] = true, ["rawset"] = true, ["rawlen"] = true, ["rawequal"] = true
	}
	
	local charPool = {}
	for i = 1, 26 do
		table.insert(charPool, string.char(96 + i))
		table.insert(charPool, string.char(64 + i))
	end
	
	for _, token in ipairs(tokens) do
		if token.type == ast.TokenType.IDENTIFIER and not protected[token.value] then
			if not varMap[token.value] then
				local char
				repeat
					char = charPool[math.random(1, #charPool)]
				until not usedChars[char]
				varMap[token.value] = char
				usedChars[char] = true
			end
		end
	end
	local result = ""
	for _, token in ipairs(tokens) do
		if token.type == ast.TokenType.IDENTIFIER and varMap[token.value] then
			result = result .. varMap[token.value]
		else
			result = result .. token.value
		end
	end
	
	return result
end

return main
