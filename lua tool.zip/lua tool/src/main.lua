local compressor = require("src.compressor")
local formatter = require("src.formatter")
local linter = require("src.linter")
local ast = require("src.ast")

local main = {}

function main.processFile(filePath, operation, options)
	local file = io.open(filePath, "r")
	if not file then
		return {success = false, error = "Could not open file: " .. filePath}
	end

	local source = file:read("*a")
	file:close()

	if operation == "compress" then
		return {success = true, result = compressor.compress(source)}
	elseif operation == "format" then
		return {success = true, result = formatter.format(source, options)}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors)}
	elseif operation == "fixcode" then
		local result = main.fixcode(source)
		return {success = true, result = result}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.processCode(source, operation, options)
	if operation == "compress" then
		return {success = true, result = compressor.compress(source)}
	elseif operation == "format" then
		return {success = true, result = formatter.format(source, options)}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors)}
	elseif operation == "fixcode" then
		local result = main.fixcode(source)
		return {success = true, result = result}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.fixcode(source)
	local tokens = ast.tokenize(source)
	local stack = {}
	local loopKeywords = {}
	for i, token in ipairs(tokens) do
		if token.type == ast.TokenType.KEYWORD and (token.value == "while" or token.value == "for") then
			loopKeywords[i] = true
		end
	end
	for i, token in ipairs(tokens) do
		if token.type == ast.TokenType.KEYWORD then
			local kw = token.value
			if kw == "if" or kw == "function" then
				table.insert(stack, {type = kw, line = token.line})
			elseif kw == "while" or kw == "for" then
				table.insert(stack, {type = kw, line = token.line})
			elseif kw == "repeat" then
				table.insert(stack, {type = "repeat", line = token.line})
			elseif kw == "do" then
				local isPartOfLoop = false
				for j = math.max(1, i - 10), i - 1 do
					if loopKeywords[j] then
						local foundEnd = false
						for k = j + 1, i - 1 do
							if tokens[k].type == ast.TokenType.KEYWORD and (tokens[k].value == "end" or tokens[k].value == "until") then
								foundEnd = true
								break
							end
						end
						if not foundEnd then
							isPartOfLoop = true
							break
						end
					end
				end
				if not isPartOfLoop then
					table.insert(stack, {type = "do", line = token.line})
				end
			elseif kw == "end" then
				if #stack > 0 then
					table.remove(stack)
				end
			elseif kw == "until" then
				if #stack > 0 and stack[#stack].type == "repeat" then
					table.remove(stack)
				end
			end
		end
	end
	local result = source
	if result:sub(-1) ~= "\n" then
		result = result .. "\n"
	end
	
	for i = 1, #stack do
		result = result .. "end\n"
	end
	
	return result
end

function main.countLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local count = 0
	local locals = {}
	local depth = 0
	for _, line in ipairs(lines) do
		local code = line
		local commentStart = line:find("%-%-")
		if commentStart then
			code = line:sub(1, commentStart - 1)
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		if code:match("^%s*local%s+") and prevDepth == 0 then
			local declarators = code:match("^%s*local%s+(.*)$")
			if declarators then
				for decl in declarators:gmatch("[^,]+") do
					decl = decl:match("^%s*(.-)%s*$") or ""
					local var = decl:match("^([%w_]+)")
					if var then
						count = count + 1
						table.insert(locals, var)
					end
				end
			end
		end
	end
	
	return count, locals
end

function main.deleteLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local result = ""
	local depth = 0
	
	for _, line in ipairs(lines) do
		local commentStart = line:find("%-%-")
		local code, comment
		
		if commentStart then
			code = line:sub(1, commentStart - 1)
			comment = line:sub(commentStart)
		else
			code = line
			comment = ""
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		
		if code:match("^%s*local%s+") and code:find("=") and prevDepth == 0 then
			local newCode = code:gsub("^(%s*)local%s+", "%1", 1)
			result = result .. newCode .. comment .. "\n"
		else
			result = result .. line .. "\n"
		end
	end
	
	return result:match("^(.-)%s*$")
end

return main
