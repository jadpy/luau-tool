local compressor = require("src.compressor")
local formatter = require("src.formatter")
local linter = require("src.linter")
local ast = require("src.ast")

local main = {}

-- List of all valid operations
main.OPERATIONS = {
	compress = true,
	format = true,
	lint = true,
	fixcode = true,
	["local"] = true,  -- Map "local" command to localcount operation
	dlocal = true,
	rename = true
}

function main.processFile(filePath, operation, options)
	local file = io.open(filePath, "r")
	if not file then
		return {success = false, error = "Could not open file: " .. filePath}
	end

	local source = file:read("*a")
	file:close()

	local stats = main.getStats(source)

	if operation == "compress" then
		local result = compressor.compress(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "format" then
		local result = formatter.format(source, options)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors), stats = stats}
	elseif operation == "fixcode" then
		local result, fixes = main.fixcode(source)
		return {success = true, result = result, fixes = fixes, dryRun = options.dryRun, stats = stats}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals, stats = stats}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	elseif operation == "rename" then
		local result = main.rename(source)
		return {success = true, result = result, dryRun = options.dryRun, stats = stats}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.processCode(source, operation, options)
	local stats = main.getStats(source)
	
	if operation == "compress" then
		local result = compressor.compress(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "format" then
		local result = formatter.format(source, options)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "lint" then
		local errors = linter.check(source)
		return {success = true, errors = errors, formatted = linter.formatErrors(errors), stats = stats}
	elseif operation == "fixcode" then
		local result, fixes = main.fixcode(source)
		return {success = true, result = result, fixes = fixes, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "localcount" then
		local count, locals = main.countLocals(source)
		return {success = true, count = count, locals = locals, stats = stats}
	elseif operation == "dlocal" then
		local result = main.deleteLocals(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	elseif operation == "rename" then
		local result = main.rename(source)
		return {success = true, result = result, dryRun = options and options.dryRun, stats = stats}
	else
		return {success = false, error = "Unknown operation: " .. operation}
	end
end

function main.getStats(source)
	-- Calculate statistics for source code
	local lines = 0
	for _ in source:gmatch("\n") do
		lines = lines + 1
	end
	if #source > 0 and source:sub(-1) ~= "\n" then
		lines = lines + 1
	end
	if lines == 0 and #source > 0 then
		lines = 1
	end
	
	local tokens = ast.tokenize(source)
	local tokenCount = #tokens - 1  -- Exclude EOF token
	
	return {
		lines = lines,
		tokens = tokenCount,
		bytes = #source
	}
end

function main.fixcode(source)
	local tokens = ast.tokenize(source)
	local stack = {}
	local fixes = {}  -- Track fixes made
	
	-- First pass: scan for unclosed blocks and missing keywords
	-- Use a more accurate depth-based tracking
	local blockStack = {}  -- Track actual depth
	
	for i, token in ipairs(tokens) do
		if token.type == ast.TokenType.KEYWORD then
			local kw = token.value
			
			if kw == "if" or kw == "function" then
				table.insert(blockStack, {type = kw, line = token.line, token_idx = i})
			elseif kw == "elseif" then
				-- elseif replaces the current if/elseif on the stack
				if #blockStack > 0 and (blockStack[#blockStack].type == "if" or blockStack[#blockStack].type == "elseif") then
					blockStack[#blockStack] = {type = "elseif", line = token.line, token_idx = i}
				else
					table.insert(blockStack, {type = "elseif", line = token.line, token_idx = i})
				end
			elseif kw == "else" then
				-- else does NOT change stack
			elseif kw == "while" or kw == "for" then
				table.insert(blockStack, {type = kw, line = token.line, token_idx = i})
			elseif kw == "repeat" then
				table.insert(blockStack, {type = "repeat", line = token.line, token_idx = i})
			elseif kw == "do" then
				-- Check if this is part of while/for
				local isPartOfLoop = false
				for j = math.max(1, i - 10), i - 1 do
					if tokens[j].type == ast.TokenType.KEYWORD and (tokens[j].value == "while" or tokens[j].value == "for") then
						local foundEnd = false
						for k = j + 1, i - 1 do
							if tokens[k].type == ast.TokenType.KEYWORD and (tokens[k].value == "end" or tokens[k].value == "until") then
								foundEnd = true
								break
							end
						end
						if not foundEnd then
							isPartOfLoop = true
							break
						end
					end
				end
				if not isPartOfLoop then
					table.insert(blockStack, {type = "do", line = token.line, token_idx = i})
				end
			elseif kw == "end" then
				if #blockStack > 0 then
					table.remove(blockStack)
				else
					-- Extra 'end' detected (not matched with any opening block)
					table.insert(fixes, {line = token.line, msg = "extra 'end' detected (unmatched)"})
				end
			elseif kw == "until" then
				if #blockStack > 0 and blockStack[#blockStack].type == "repeat" then
					table.remove(blockStack)
				elseif #blockStack == 0 then
					table.insert(fixes, {line = token.line, msg = "extra 'until' detected (unmatched)"})
				end
			end
		end
	end
	
	-- Store the final stack for comparison
	stack = blockStack
	
	-- Second pass: rebuild source with missing keywords inserted
	local result = ""
	local i = 1
	while i <= #tokens do
		local token = tokens[i]
		result = result .. token.value
		
		if token.type == ast.TokenType.KEYWORD then
			local kw = token.value
			
			-- Check if 'if' or 'elseif' is followed by 'then'
			if kw == "if" or kw == "elseif" then
				local foundThen = false
				for j = i + 1, math.min(i + 20, #tokens) do
					if tokens[j].type == ast.TokenType.KEYWORD then
						if tokens[j].value == "then" then
							foundThen = true
							break
						elseif tokens[j].value == "if" or tokens[j].value == "end" then
							break
						end
					end
				end
				if not foundThen then
					-- Consume tokens until newline, then add 'then'
					local insertIdx = i + 1
					while insertIdx <= #tokens and tokens[insertIdx].value ~= "\n" do
						result = result .. tokens[insertIdx].value
						insertIdx = insertIdx + 1
					end
					result = result .. " then"
					i = insertIdx - 1
					table.insert(fixes, {line = token.line, msg = "added 'then' after '" .. kw .. "'"})
				end
			end
			
			-- Check if 'while' or 'for' is followed by 'do'
			if kw == "while" or kw == "for" then
				local foundDo = false
				for j = i + 1, math.min(i + 20, #tokens) do
					if tokens[j].type == ast.TokenType.KEYWORD then
						if tokens[j].value == "do" then
							foundDo = true
							break
						elseif tokens[j].value == "then" or tokens[j].value == "end" then
							break
						end
					end
				end
				if not foundDo then
					-- Consume tokens until newline, then add 'do'
					local insertIdx = i + 1
					while insertIdx <= #tokens and tokens[insertIdx].value ~= "\n" do
						result = result .. tokens[insertIdx].value
						insertIdx = insertIdx + 1
					end
					result = result .. " do"
					i = insertIdx - 1
					table.insert(fixes, {line = token.line, msg = "added 'do' after '" .. kw .. "'"})
				end
			end
		end
		
		i = i + 1
	end
	
	-- Add missing 'end' / 'until' for unclosed blocks
	for _, block in ipairs(stack) do
		result = result .. "\n"
		if block.type == "repeat" then
			result = result .. "until false"
			table.insert(fixes, {line = block.line, msg = "added 'until false' for repeat"})
		else
			result = result .. "end"
			table.insert(fixes, {line = block.line, msg = "added 'end' for '" .. block.type .. "'"})
		end
	end
	
	-- Third pass: remove excess 'end' keywords by counting properly
	local resultTokens = ast.tokenize(result)
	local openerCount = 0
	local closerCount = 0
	local lastEndTokenIdx = nil
	
	for i, token in ipairs(resultTokens) do
		if token.type == ast.TokenType.KEYWORD then
			local kw = token.value
			-- Count opening blocks
			if kw == "if" or kw == "while" or kw == "for" or kw == "function" or kw == "repeat" then
				openerCount = openerCount + 1
			elseif kw == "do" then
				-- Check if this 'do' is part of while/for (don't count it as separate opener)
				local isPartOfLoop = false
				for j = math.max(1, i - 20), i - 1 do
					if resultTokens[j].type == ast.TokenType.KEYWORD and (resultTokens[j].value == "while" or resultTokens[j].value == "for") then
						local foundEnd = false
						for k = j + 1, i - 1 do
							if resultTokens[k].type == ast.TokenType.KEYWORD and (resultTokens[k].value == "end" or resultTokens[k].value == "until") then
								foundEnd = true
								break
							end
						end
						if not foundEnd then
							isPartOfLoop = true
							break
						end
					end
				end
				if not isPartOfLoop then
					openerCount = openerCount + 1
				end
			end
			
			-- Count closing blocks
			if kw == "end" then
				closerCount = closerCount + 1
				lastEndTokenIdx = i  -- Track last 'end' position
			elseif kw == "until" then
				closerCount = closerCount + 1
			end
		end
	end
	
	-- If we have excess 'end' keywords, remove the last one(s)
	if closerCount > openerCount and lastEndTokenIdx then
		local excessCount = closerCount - openerCount
		-- Remove excess 'end' tokens starting from the last one
		local endTokensToSkip = {}
		local endCount = 0
		
		-- Count backwards from the end to find which 'end' tokens to remove
		for i = #resultTokens, 1, -1 do
			if resultTokens[i].type == ast.TokenType.KEYWORD and resultTokens[i].value == "end" then
				endCount = endCount + 1
				if endCount <= excessCount then
					table.insert(endTokensToSkip, i)
				end
			end
		end
		
		-- Rebuild without excess 'end' tokens
		result = ""
		for i, token in ipairs(resultTokens) do
			local skip = false
			for _, skipIdx in ipairs(endTokensToSkip) do
				if i == skipIdx then
					skip = true
					table.insert(fixes, {line = token.line, msg = "removed excess 'end'"})
					break
				end
			end
			if not skip then
				result = result .. token.value
			end
		end
	end
	
	-- Ensure trailing newline
	if result:sub(-1) ~= "\n" then
		result = result .. "\n"
	end
	
	return result, fixes
end

function main.countLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local count = 0
	local locals = {}
	local depth = 0
	for _, line in ipairs(lines) do
		local code = line
		local commentStart = line:find("%-%-")
		if commentStart then
			code = line:sub(1, commentStart - 1)
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		if code:match("^%s*local%s+") and prevDepth == 0 then
			local declarators = code:match("^%s*local%s+(.*)$")
			if declarators then
				for decl in declarators:gmatch("[^,]+") do
					decl = decl:match("^%s*(.-)%s*$") or ""
					local var = decl:match("^([%w_]+)")
					if var then
						count = count + 1
						table.insert(locals, var)
					end
				end
			end
		end
	end
	
	return count, locals
end

function main.deleteLocals(source)
	local lines = {}
	for line in source:gmatch("([^\n]*)\n?") do
		table.insert(lines, line)
	end
	
	local result = ""
	local depth = 0
	
	for _, line in ipairs(lines) do
		local commentStart = line:find("%-%-")
		local code, comment
		
		if commentStart then
			code = line:sub(1, commentStart - 1)
			comment = line:sub(commentStart)
		else
			code = line
			comment = ""
		end
		local openCount = (code:match("if%s") and 1 or 0) +
		                  (code:match("while%s") and 1 or 0) +
		                  (code:match("for%s") and 1 or 0) +
		                  (code:match("function%s") and 1 or 0) +
		                  (code:match("do%s") and 1 or 0) +
		                  (code:match("repeat%s") and 1 or 0)
		
		local closeCount = (code:match("end") and 1 or 0) +
		                   (code:match("until") and 1 or 0)
		
		local prevDepth = depth
		depth = math.max(0, depth + openCount - closeCount)
		
		if code:match("^%s*local%s+") and code:find("=") and prevDepth == 0 then
			local newCode = code:gsub("^(%s*)local%s+", "%1", 1)
			result = result .. newCode .. comment .. "\n"
		else
			result = result .. line .. "\n"
		end
	end
	
	return result:match("^(.-)%s*$")
end

function main.rename(source)
	local tokens = ast.tokenize(source)
	local varMap = {}  -- Map: original_name -> single_char
	local usedChars = {}
	
	-- Predefined Lua keywords and builtins that should NOT be renamed
	local protected = {
		-- Keywords
		["if"] = true, ["then"] = true, ["else"] = true, ["elseif"] = true, ["end"] = true,
		["for"] = true, ["while"] = true, ["repeat"] = true, ["until"] = true, ["do"] = true,
		["function"] = true, ["local"] = true, ["return"] = true, ["break"] = true,
		["and"] = true, ["or"] = true, ["not"] = true, ["nil"] = true, ["true"] = true, ["false"] = true,
		["in"] = true, ["continue"] = true,
		-- Builtin functions
		["print"] = true, ["type"] = true, ["typeof"] = true, ["pairs"] = true, ["ipairs"] = true,
		["next"] = true, ["tonumber"] = true, ["tostring"] = true, ["assert"] = true, ["error"] = true,
		["pcall"] = true, ["xpcall"] = true, ["load"] = true, ["loadstring"] = true, ["require"] = true,
		["module"] = true, ["os"] = true, ["io"] = true, ["math"] = true, ["string"] = true, ["table"] = true,
		["debug"] = true, ["coroutine"] = true, ["setmetatable"] = true, ["getmetatable"] = true,
		["rawget"] = true, ["rawset"] = true, ["rawlen"] = true, ["rawequal"] = true
	}
	
	-- Character pool for obfuscation (lowercase + uppercase)
	local charPool = {}
	for i = 1, 26 do
		table.insert(charPool, string.char(96 + i))  -- a-z
		table.insert(charPool, string.char(64 + i))  -- A-Z
	end
	
	-- First pass: collect all identifiers
	for _, token in ipairs(tokens) do
		if token.type == ast.TokenType.IDENTIFIER and not protected[token.value] then
			if not varMap[token.value] then
				-- Generate random single character not yet used
				local char
				repeat
					char = charPool[math.random(1, #charPool)]
				until not usedChars[char]
				varMap[token.value] = char
				usedChars[char] = true
			end
		end
	end
	
	-- Second pass: rebuild source with renamed identifiers
	local result = ""
	for _, token in ipairs(tokens) do
		if token.type == ast.TokenType.IDENTIFIER and varMap[token.value] then
			result = result .. varMap[token.value]
		else
			result = result .. token.value
		end
	end
	
	return result
end

return main
