local roblox = {}

roblox.Classes = {
	Vector3 = {
		new = "function",
		zero = "variable",
		one = "variable",
		unit = "variable"
	},
	Color3 = {
		new = "function",
		fromRGB = "function",
		fromHSV = "function"
	},
	CFrame = {
		new = "function",
		Angles = "function",
		lookAlong = "function"
	},
	Instance = {
		new = "function",
		FindFirstChild = "method",
		Clone = "method",
		Destroy = "method"
	},
	game = {
		GetService = "method",
		Loaded = "signal"
	},
	script = {
		Parent = "property",
		Name = "property"
	},
	workspace = {
		FindPartOnRay = "method",
		Terrain = "property"
	}
}

roblox.GlobalFunctions = {
	"print",
	"warn",
	"error",
	"assert",
	"type",
	"typeof",
	"pairs",
	"ipairs",
	"next",
	"table",
	"string",
	"math",
	"bit32"
}

function roblox.isRobloxClass(name)
	return roblox.Classes[name] ~= nil
end

function roblox.isGlobalFunction(name)
	for _, fname in ipairs(roblox.GlobalFunctions) do
		if fname == name then
			return true
		end
	end
	return false
end

function roblox.getClassMembers(className)
	if roblox.Classes[className] then
		return roblox.Classes[className]
	end
	return nil
end

return roblox
