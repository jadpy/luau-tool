# Luau Tool - Copilot Instructions

This project is a Luau code processing tool that uses AST-based transformations.

## Project Overview
- **Type**: TypeScript/Node.js CLI tool
- **Target Language**: Luau
- **Main Features**:
  - Code formatting with proper indentation
  - Code minification with variable shortening
  - Linting for error detection

## Key Components
1. **Lexer** (`lexer.ts`) - Tokenizes Luau source code
2. **Parser** (`parser.ts`) - Builds AST from tokens
3. **Formatter** (`formatter.ts`) - Outputs formatted code
4. **Minifier** (`minifier.ts`) - Shortens variable names and reduces code
5. **Linter** (`linter.ts`) - Detects errors and issues

## Development Guidelines
- Maintain AST structure consistency across all modules
- Add comprehensive error handling in parser
- Keep token types in sync with lexer
- Test with various Luau code samples

## Next Steps
- Implement comprehensive test suite
- Add CLI interface for command-line usage
- Enhance error reporting with better diagnostics
- Add support for Luau-specific features
